package com.example.carrepair;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarRepairEstimateApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarRepairEstimateApplication.class, args);
	}

}
